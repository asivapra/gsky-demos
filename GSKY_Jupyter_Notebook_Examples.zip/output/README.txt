This directory must be present and writeable to the Jupyter Notebook.
